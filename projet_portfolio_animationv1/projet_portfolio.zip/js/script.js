new Typed (".ex", {
    strings: ["tant pis", "First sentence","Second sentence","jeej","tuuj","aoin"],
    typeSpeed : 20
    });